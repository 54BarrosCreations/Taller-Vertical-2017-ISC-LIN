# Taller-Vertical-2017-ISC-LIN
RepoTallerVertical2017
