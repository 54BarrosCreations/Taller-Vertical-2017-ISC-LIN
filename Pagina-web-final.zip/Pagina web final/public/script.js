// script.js

    // create the module and name it scotchApp
        // also include ngRoute for all our routing needs
    var scotchApp = angular.module('scotchApp', ['ngRoute']);

    // configure our routes
    scotchApp.config(function($routeProvider) {
        $routeProvider

            // route for the home page
            .when('/', {
                templateUrl : 'home.html',
                controller  : 'mainController'
            })

            // route for the about page
            .when('/about', {
                templateUrl : 'pages/about.html',
                controller  : 'aboutController'
            })

            // route for the contact page
            .when('/contact', {
                templateUrl : 'pages/contact.html',
                controller  : 'contactController'
            })
            // route for the Q1 page
            .when('/Q', {
                templateUrl : 'pages/Q.html',
                controller  : 'Q1Controller'
            })

            // route for the Q1 page
            .when('/Q1', {
                templateUrl : 'pages/Q1.html',
                controller  : 'Q1Controller'
            })
            // route for the Q2 page
            .when('/Q2', {
                templateUrl : 'pages/Q2.html',
                controller  : 'Q2Controller'
            })
            // route for the Q3 page
            .when('/Q3', {
                templateUrl : 'pages/Q3.html',
                controller  : 'Q3Controller'
            })

            // route for the Q4 page
            .when('/Q4', {
                templateUrl : 'pages/Q4.html',
                controller  : 'Q4Controller'
            })

            // route for the Q page
            .when('/Q5', {
                templateUrl : 'pages/registration.html',
                controller  : 'Q5Controller'
            })

                        // route for the Q page
            .when('/registration', {
                templateUrl : 'pages/registration.html',
                controller  : 'registrationController'
            })

            // route for the contact page
            .when('/doctors', {
                templateUrl : 'pages/doctors.html',
                controller  : 'doctorsController'
            });
    });

    // create the controller and inject Angular's $scope
    scotchApp.controller('mainController', function($scope) {
        
    });

    scotchApp.controller('aboutController', function($scope, $http) {
        $scope.message = 'Look! I am an about page.';
          $http.get("/about").then(function (response) {
            console.log(response);
            $scope.title = response.data.title;
        });
    });

    scotchApp.controller('contactController', function($scope, $http) {
        $scope.message = 'Contact us! JK. This is just a demo.';
        $http.get("/contact").then(function (response) {
            console.log(response.data[0].city);
            $scope.names = response.data;
        });
    });

        scotchApp.controller('doctorsController', function($scope, $http) {
        $scope.message = 'Doctores disponibles lipo';
        $http.get("/doctors").then(function (response) {
            //$scope.names = response.data;
        });
    });